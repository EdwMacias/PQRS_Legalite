package com.legality_PQR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LegalityPqrApplicationTests {

	@Test
	void contextLoads() {
	}

}
