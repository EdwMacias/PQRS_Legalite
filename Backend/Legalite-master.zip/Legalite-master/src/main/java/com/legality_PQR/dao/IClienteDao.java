package com.legality_PQR.dao;

import org.springframework.data.repository.CrudRepository;

import com.legality_PQR.model.Cliente;

public interface IClienteDao extends CrudRepository<Cliente, Long>{

}
