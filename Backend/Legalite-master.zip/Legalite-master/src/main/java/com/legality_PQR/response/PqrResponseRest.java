package com.legality_PQR.response;


public class PqrResponseRest extends ResponseRest{
	


	private PqrResponse pqrResponse = new PqrResponse();

	public PqrResponse getPqrResponse() {
		return pqrResponse;
	}

	public void setPqrResponse(PqrResponse pqrResponse) {
		this.pqrResponse = pqrResponse;
	}



}
