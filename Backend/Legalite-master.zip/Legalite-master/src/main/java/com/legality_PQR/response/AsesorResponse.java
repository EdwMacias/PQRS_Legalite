package com.legality_PQR.response;

import java.util.List;

import com.legality_PQR.model.Asesor;
import com.legality_PQR.model.Cliente;
import com.legality_PQR.model.Lider;

public class AsesorResponse {
	
	private List<Asesor> asesor;

	public List<Asesor> getAsesor() {
		return asesor;
	}

	public void setAsesor(List<Asesor> asesor) {
		this.asesor = asesor;
	}

}
