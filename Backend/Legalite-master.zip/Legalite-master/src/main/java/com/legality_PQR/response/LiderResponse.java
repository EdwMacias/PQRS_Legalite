package com.legality_PQR.response;

import java.util.List;

import com.legality_PQR.model.Asesor;
import com.legality_PQR.model.Cliente;
import com.legality_PQR.model.Lider;

public class LiderResponse {
	
	private List<Lider> lider;
	
	public List<Lider> getLider() {
		return lider;
	}

	public void setLider(List<Lider> lider) {
		this.lider = lider;
	}
	
	

}
