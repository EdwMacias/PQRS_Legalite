package com.legality_PQR.dao;

import org.springframework.data.repository.CrudRepository;

import com.legality_PQR.model.Pqr;

public interface IPqrDao extends CrudRepository<Pqr, Long>{
	
	

}
