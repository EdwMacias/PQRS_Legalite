package com.legality_PQR.response;

public class LiderResponseRest extends ResponseRest{


	private LiderResponse liderResponse = new LiderResponse();

	public LiderResponse getLiderResponse() {
		return liderResponse;
	}

	public void setLiderResponse(LiderResponse liderResponse) {
		this.liderResponse = liderResponse;
	}
	
	

}
