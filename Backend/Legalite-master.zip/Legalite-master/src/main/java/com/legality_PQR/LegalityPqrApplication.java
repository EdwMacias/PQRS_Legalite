package com.legality_PQR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LegalityPqrApplication {

	public static void main(String[] args) {
		SpringApplication.run(LegalityPqrApplication.class, args);
	}

}
