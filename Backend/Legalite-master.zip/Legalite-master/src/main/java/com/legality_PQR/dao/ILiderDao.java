package com.legality_PQR.dao;

import org.springframework.data.repository.CrudRepository;

import com.legality_PQR.model.Lider;

public interface ILiderDao extends CrudRepository<Lider, Long>{

}
