package com.legality_PQR.dao;

import org.springframework.data.repository.CrudRepository;

import com.legality_PQR.model.Asesor;

public interface IAsesorDao extends CrudRepository<Asesor, Long>{

}
