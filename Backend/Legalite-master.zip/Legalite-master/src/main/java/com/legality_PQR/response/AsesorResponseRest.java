package com.legality_PQR.response;

public class AsesorResponseRest extends ResponseRest{


	private AsesorResponse asesorResponse = new AsesorResponse();
	
	public AsesorResponse getAsesorResponse() {
		return asesorResponse;
	}

	public void setAsesorResponse(AsesorResponse asesorResponse) {
		this.asesorResponse = asesorResponse;
	}

}
